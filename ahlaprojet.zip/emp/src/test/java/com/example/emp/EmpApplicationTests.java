package com.example.emp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpApplicationTests {

	@Test
	void contextLoads() {
	}

}
